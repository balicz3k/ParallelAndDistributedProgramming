Laboratorium 4 (MPI) - Jakub Balicki

Pliki:
  przyklad.c         punkt 2 - program przykladowy (prz_mpi)
  ring.c             punkt 3 - pierscien (MPI_Send / MPI_Recv)
  bcast.c            punkt 4 - rozglaszanie (MPI_Bcast)
  scatter_gather.c   punkt 5 - suma tablicy (MPI_Scatter / MPI_Scatterv, MPI_Gather, MPI_Wtime)
  Makefile           kompilacja i uruchamianie
  run_benchmark.sh   pomiary czasu dla p = 2..8 (30 powtorzen)
  results.txt        wyjscie programow (make results)
  results_raw.csv    surowe pomiary, N = 10000
  results_raw_duze.csv  surowe pomiary, N = 10 000 000
  sprawozdanie/plot_results.py  wykres i tabela do sprawozdania

Kompilacja: make
Uruchomienie: make run_przyklad | make run_ring | make run_bcast | make run_scatter
Pomiary:      make benchmark, potem: cd sprawozdanie && python3 plot_results.py
